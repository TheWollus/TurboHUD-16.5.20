function CalculateRadiusWithPing(radius, pingSpeed)
	local mod = 1.0
	if (pingSpeed > 0) then
		local msec = CurrentMilliseconds()
		if ((math.floor(msec / pingSpeed)) % 2 == 1) then
			mod = 0.5 + 0.5 * (msec % pingSpeed) / pingSpeed
		else
			mod = 1.0 - 0.5 * (msec % pingSpeed) / pingSpeed
		end
    end
	return radius * mod
end

function UserActivatedAutoScript()
	return IsPressed("CapsLock")
end

function IsInventoryLockSet()
	local rect = GetInventoryLockArea()
	return (rect.Width ~= 0 and rect.Height ~= 0)
end
