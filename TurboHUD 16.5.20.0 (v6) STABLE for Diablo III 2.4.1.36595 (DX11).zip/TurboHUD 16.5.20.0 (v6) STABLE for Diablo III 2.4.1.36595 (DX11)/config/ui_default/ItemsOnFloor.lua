ItemsOnFloor = {}

-- CONTROLLER VARIABLES, READY FOR OVERRIDE FROM OTHER SCRIPTS --
ItemsOnFloor.Enabled = true
ItemsOnFloor.LabelPadding = 3;
-----------------------------------------------------------------

-- All methods starting with "PaintFloor" are automatically called by the overlay
function ItemsOnFloor.PaintFloor()
	if (not ItemsOnFloor.Enabled) then return end

	local items = GetItems("Floor")
	for i, item in ipairs(items) do

		if (item.OnScreen and item.Unidentified and (item.Quality == "Legendary")) then
			local bgFormat, borderFormat, textFormat, circleFormat = ItemsOnFloor.GetItemFormatForLegendary(item)
			
			local radius = ItemsOnFloor.GetItemRadius(item)
			local pingSpeed = ItemsOnFloor.GetPingSpeed(item)
			radius = CalculateRadiusWithPing(radius, pingSpeed)

			DrawWorldCircle(circleFormat, item.FloorWC, radius)
			ItemsOnFloor.PaintItemLabel(bgFormat, borderFormat, textFormat, item)
		end
	end
end

function ItemsOnFloor.GetItemRadius(item)
	if (item.IsSet) then
		if (item.AncientRank > 0) then
			return 2.2
		else
			return 1.5
		end
	else
		if (item.AncientRank > 0) then
			return 2.2
		else
			return 1.5
		end
	end
end

function ItemsOnFloor.GetPingSpeed(item)
	if (item.AncientRank > 0) then
		return 500
	else
		return 0
	end
end

function ItemsOnFloor.GetItemFormatForLegendary(item)
	local bfCircleLegendary = "ItemsOnFloor.CircleLegendary"
	CreateBrushFormat(bfCircleLegendary, 192, 235, 120, 0, -2)

	local bfCircleAncient = "ItemsOnFloor.CircleAncient"
	CreateBrushFormat(bfCircleAncient, 192, 255, 140, 0, -3)

	local bfCircleLegendarySet = "ItemsOnFloor.CircleLegendarySet"
	CreateBrushFormat(bfCircleLegendarySet, 192, 50, 220, 50, -2)

	local bfCircleAncientSet = "ItemsOnFloor.CircleAncientSet"
	CreateBrushFormat(bfCircleAncientSet, 192, 85, 255, 85, -3)

	local bgFormat = "ItemsOnFloor.Bg"
	CreateBrushFormat(bgFormat, 160, 0, 0, 0, 0)

	local tfLabelLegendary = "ItemsOnFloor.LabelLegendary"
	CreateTextFormat(tfLabelLegendary, "tahoma", 7, 255, 235, 120, 0, true, false)

	local tfLabelAncient = "ItemsOnFloor.LabelAncient"
	CreateTextFormat(tfLabelAncient, "tahoma", 7, 255, 255, 140, 0, true, false)

	local tfLabelLegendarySet = "ItemsOnFloor.LabelLegendarySet"
	CreateTextFormat(tfLabelLegendarySet, "tahoma", 7, 255, 0, 170, 0, true, false)

	local tfLabelAncientSet = "ItemsOnFloor.LabelAncientSet"
	CreateTextFormat(tfLabelAncientSet, "tahoma", 7, 255, 50, 220, 50, true, false)

	local bfBorderLegendary = nil

	local bfBorderAncient = "ItemsOnFloor.BorderAncient"
	CreateBrushFormat(bfBorderAncient, 160, 255, 140, 0, -1)

	local bfBorderAncientSet = "ItemsOnFloor.BorderAncientSet"
	CreateBrushFormat(bfBorderAncientSet, 160, 50, 220, 50, -1)

	local bfBorder = bfBorderLegendary
	local tfLabel = tfLabelLegendary
	local bfCircle = bfCircleLegendary
	if (item.IsSet) then
		if (item.AncientRank > 0) then
			tfLabel = tfLabelAncientSet
			bfBorder = bfBorderAncientSet
			bfCircle = bfCircleAncientSet
		else
			tfLabel = tfLabelLegendarySet
			bfCircle = bfCircleLegendarySet
		end
	else
		if (item.AncientRank > 0) then
			tfLabel = tfLabelAncient
			bfBorder = bfBorderAncient
			bfCircle = bfCircleAncient
		end
	end

	return bgFormat, bfBorder, tfLabel, bfCircle
end

function ItemsOnFloor.PaintItemLabel(bgFormat, borderFormat, textFormat, item)
	local text = item.DisplayName
	local textSize = GetTextSize(text, textFormat)

	local coord = item.FloorWC.ToScreenCoordinate(true, true)
	local rect = Rectangle.__new(coord.X - textSize.Width / 2 - ItemsOnFloor.LabelPadding, coord.Y - textSize.Height / 2 - ItemsOnFloor.LabelPadding, textSize.Width + ItemsOnFloor.LabelPadding * 2, textSize.Height + ItemsOnFloor.LabelPadding * 2);
	rect = Rectangle.Inflate(rect, 2, 0)

	if (bgFormat ~= nil) then
		DrawRectangle(bgFormat, rect.X, rect.Y, rect.Width, rect.Height)
	end

	DrawText(text, textFormat, coord.X - textSize.Width / 2, coord.Y - textSize.Height / 2)

	if (borderFormat ~= nil) then
		DrawRectangle(borderFormat, rect.X, rect.Y, rect.Width, rect.Height)
	end
end